<table>
	<tr>
	<td><p style="text-transform: capitalize;font-weight:bold">Dear <?php echo $name; ?>,</p></td>
	</tr>
	<tr>
		<td>
			<p>New <?php echo $request_type; ?>(<?php echo $qnty; ?>) requests has been generated.</p>
     		 <p>You can verify these requests by logging through the following link <a href="http://www.salasarholidays.com"> Click here </a> </p> 
		</td>
	</tr>

	<tr>
		<td style="text-transform: capitalize;font-weight:bold">
			<p>Regards</p>
			<p>Salasar Group</p>
			<p>Headquarters</p>
			<p>409, 4th Floor, Princess Business Sky Park,</p>
			<p>Scheme No. 54, PU-3 Commercial,</p>
			<p>Opp. Orbit Mall, A.B. Road,</p>
			<p>Indore 452010 (M.P.)</p>
			<p>Phone: 0731-4030288</p>
			<p>Email: :techsupport@salasar-travels.com</p>
		</td>
	</tr>
</table>