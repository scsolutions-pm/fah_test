<table>

	<tr>

	<td><p style="text-transform: capitalize;font-weight:bold">Dear <?php echo $name; ?>,</p></td>

	</tr>

	<tr>

		<td>

			<p>New Hotel requests has been generated.</p>

			 <p>You can verify this request by using the following link <a href="http://www.salasar-travels.com"> Click here </a> </p> 

		</td>

	</tr>

	<tr>

		<td style="text-transform: capitalize;font-weight:bold">

			<p>Regards & Thank You. </p>

			<p>Salasar Group</p>

			<p>Headquarters</p>

			<p>107, Sudama Nagar</p>

			<p>Ujjain, M.P.</p>



			<p>Phone: 0734-2556000</p>

			<p>Email: :info@salasar-travels.com</p>

			<p>Skype: salasar1 </p>

		</td>

	</tr>

</table>