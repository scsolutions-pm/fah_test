<table>

	<tr>
	<td><p style="text-transform: capitalize;font-weight:bold">Dear <?php echo $name; ?>,</p></td>
	</tr>

	<tr>
		<td>
			<p>Your Vehicle request <?php echo $c_request_id; ?> has been processed</p>
			<p>Your Vehicle details are as follows :
			<p>CAB no. : <?php echo $vehicle_number; ?> </p>
			<p>Driver's Name : <?php echo $driver_name; ?> </p>
			<p>Driver's Contact no. :<?php echo $contact_number; ?> </p>


			 <p>For any queries and emergencies you can communicate 24x7 to our help desk toll free no.(----)</p>

		</td>

	</tr>

	<tr>

		<td style="text-transform: capitalize;font-weight:bold">

			<p> # Have happy and safe journey # </p>
			
			<p>Regards</p>
			<p>Salasar Group</p>
			<p>Headquarters</p>
			<p>107, Sudama Nagar</p>
			<p>Ujjain, M.P.</p>

			<p>Phone: 0734-2556000</p>
			<p>Email: :info@salasar-travels.com</p>
			<p>Skype: salasar1 </p>

		</td>

	</tr>

</table>