<table>
	<tr>
	<td><p style="text-transform: capitalize;font-weight:bold">Dear User,</p></td>
	</tr>

	<tr>
		<td>
			<p>To reset your password for online cab booking portal click on link given below :</p>
			<p> <?php echo  site_url(); ?>/Home/updatePswdForm/<?php echo $auth_link_code; ?></p>

			 <p>For any queries and emergencies you can communicate 24x7 to our help desk toll free no.(----)</p>

		</td>
	</tr>

	<tr>
		<td style="text-transform: capitalize;font-weight:bold">
			<p> # Have happy and safe journey # </p>
			
			<p>Regards</p>
			<p>Salasar Group</p>
			<p>Headquarters</p>
			<p>409, 4th Floor, Princess Business Sky Park,</p>
			<p>Scheme No. 54, PU-3 Commercial,</p>
			<p>Opp. Orbit Mall, A.B. Road,</p>
			<p>Indore 452010 (M.P.)</p>
			<p>Phone: 0731-4030288</p>
			<p>Email: :techsupport@salasar-travels.com</p>
		</td>
	</tr>

</table>