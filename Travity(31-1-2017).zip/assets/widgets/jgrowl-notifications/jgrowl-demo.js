  /* jGrowl notifications */

  $(function() {

      $('.growl-example-1').click(function() {

          $.jGrowl("jGrowl notification example with lorem ipsum dolor sic amet.", {
              sticky: false,
              position: 'top-right',
              theme: 'bg-blue-alt'
          });

      });

      $('.growl-example-2').click(function() {

          $.jGrowl("jGrowl notification example with lorem ipsum dolor sic amet.", {
              sticky: false,
              position: 'top-right',
              theme: 'bg-azure'
          });

      });

      $('.growl-example-3').click(function() {

          $.jGrowl("jGrowl notification example with lorem ipsum dolor sic amet.", {
              sticky: false,
              position: 'top-right',
              theme: 'bg-orange'
          });

      });

      $('.growl-example-4').click(function() {

          $.jGrowl("jGrowl notification example with lorem ipsum dolor sic amet.", {
              sticky: false,
              position: 'top-right',
              theme: 'bg-gray'
          });

      });

      $('.growl-example-5').click(function() {

          $.jGrowl("jGrowl notification example with lorem ipsum dolor sic amet.", {
              sticky: false,
              position: 'top-right',
              theme: 'bg-green'
          });

      });

      $('.growl-example-6').click(function() {

          $.jGrowl("jGrowl notification example with lorem ipsum dolor sic amet.", {
              sticky: false,
              position: 'top-right',
              theme: 'bg-red'
          });

      });


  });
