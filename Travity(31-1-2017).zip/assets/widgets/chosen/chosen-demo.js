
/* Chosen select */

$(function() { "use strict";

    $(".chosen-select").chosen();

    $(".chosen-search").append('<i class="glyph-icon icon-search"></i>');
    $(".chosen-single div").html('<i class="glyph-icon icon-caret-down"></i>');

});
