	/* Layerslider */
	$(function() {
	    "use strict";
	    jQuery("#layerslider").layerSlider({
	        responsive: true,
            responsiveUnder : 960,
            layersContainer : 1270,
	        skin: 'fullwidth',
	        hoverPrevNext: true,
	        skinsPath: '../assets/widgets/layerslider/skins/'
	    });
	});
